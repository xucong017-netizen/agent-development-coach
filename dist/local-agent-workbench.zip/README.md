# 本地智能体教学工作台 · 1.2.0

需要 Python 3.10+，无需安装其他依赖。Windows 解压整个压缩包，双击“启动工作台.bat”，浏览器会打开 http://127.0.0.1:8766。终端窗口保持运行。

默认打开 project 中的课堂模拟示例。接自己的项目：把项目文件夹拖到启动器上，或运行：

```text
python scripts/workbench.py --project "你的项目目录" --port 8766 --open
```

项目须含 agent-design/teaching-state.json。让新版 agent-development-coach Skill 初始化或继续你的项目后再打开。不要用示例进度覆盖自己的项目。端口被占用可用 --port 8767。Mac/Linux 使用上述 Python 命令。

五个视图：结构课堂、文件与代码、架构地图、运行演练、项目全貌。每 2.5 秒读取文件变化；无网页草稿时自动刷新，有草稿时提示新成果。保存设计/笔记/图写入进度 JSON；保存文档/代码写回对应文件；原内容备份于项目 .workbench/backups。

网页修改的代码不会自动执行，改图不会自动生成代码。请在 WorkBuddy 说“读取网页修改，复核相关结构和代码，更新讲解后继续”。设计决定要由 Skill 同步到正文与契约。

独立 HTML 导出：

```text
python scripts/workbench.py --project "你的项目目录" --export "成果副本.html"
```

单个 HTML 副本保存的是浏览器草稿，不能直接写回磁盘项目。用本地服务才能实时同步。网页可导出全部成果 JSON 或单个文本文件；导入进度只导入 state。

附带示例查询函数可以运行：python project/implementation/tools.py Python。只有该函数为实际本地执行，完整图轨迹是模拟，模型和 LangGraph 尚未接通。
