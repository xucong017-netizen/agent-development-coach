@echo off
chcp 65001 >nul
setlocal
set "AGENT_PROJECT=%~1"
if not defined AGENT_PROJECT set "AGENT_PROJECT=%~dp0project"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 "%~dp0scripts\workbench.py" --project "%AGENT_PROJECT%" --port 8766 --open
) else (
  python "%~dp0scripts\workbench.py" --project "%AGENT_PROJECT%" --port 8766 --open
)
if errorlevel 1 (
  echo 启动失败。请确认 Python 3.10+ 已安装、项目有教学进度、8766 端口可用。
  echo 可在终端用 --port 8767 更换端口；详细方法见 README.md。
  pause
)
endlocal
